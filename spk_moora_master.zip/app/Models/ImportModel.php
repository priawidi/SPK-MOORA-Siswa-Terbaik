<?php

namespace App\Models;

use CodeIgniter\Model;

class ImportModel extends Model
{
    public function getImportData()
    {
    }
}
