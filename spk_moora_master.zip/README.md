
 SPK untuk menentukan siswa terbaik di SMPN 272 Jakarta dengan metode MOORA
