$(document).ready(function () {
  $("#dataTable").DataTable();
  $("#dataTable2").DataTable();
  $("#dataTable3").DataTable();
  $("#dataTable4").DataTable();
  $("#dataTable5").DataTable();
  $("#dataTable6").DataTable();
  $("#dataTable7").DataTable({ order: [[3, "asc"]] });
  $("#dataTable8").DataTable({ order: [[3, "asc"]] });
  $("#dataTable9").DataTable({ order: [[3, "asc"]] });
});
