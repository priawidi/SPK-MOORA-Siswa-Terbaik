<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class GuruController extends BaseController
{
    public function index()
    {
        return view('guru/index');
    }
}
