<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Debug\Toolbar\Collectors\Views;

class Home extends BaseController
{
    public function index()
    {
    }
}
